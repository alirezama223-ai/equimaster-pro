import { Horse } from "@/app/data/horses";

type Props = {
  horse: Horse;
};

export default function ContactSeller({ horse }: Props) {
  return (
    <section className="bg-[#111827] rounded-3xl p-8 flex justify-between items-center">
      <div>
        <h2 className="text-3xl font-bold">
          Interested in {horse.name}?
        </h2>

        <p className="text-gray-400 mt-2">
          Contact the seller for more information.
        </p>
      </div>

      <button className="bg-blue-600 px-8 py-4 rounded-xl">
        Contact Seller
      </button>
    </section>
  );
}