import { Horse } from "@/app/data/horses";

type Props = {
  horse: Horse;
};

export default function HorseInfo({ horse }: Props) {
  return (
    <div className="space-y-8">

      <div>
        <h1 className="text-5xl font-bold">{horse.name}</h1>

        <p className="text-blue-400 mt-2">
          Premium Sport Horse
        </p>
      </div>

      <div className="grid grid-cols-2 gap-4">

        <InfoCard title="Breed" value={horse.breed} />

        <InfoCard title="Age" value={`${horse.age} years`} />

        <InfoCard title="Height" value={`${horse.height} cm`} />

        <InfoCard title="Country" value={horse.country} />

        <InfoCard title="Gender" value="Mare" />

        <InfoCard title="Training" value="1.40 m" />

        <InfoCard title="Color" value="Bay" />

        <InfoCard title="Health" value="Vet Checked" />

      </div>

      <div className="bg-gradient-to-r from-blue-700 to-blue-500 rounded-3xl p-8">

        <p className="text-gray-200 text-sm">
          Price
        </p>

        <h2 className="text-5xl font-bold mt-2">
          {horse.price}
        </h2>

        <div className="mt-8 space-y-4">

          <button className="w-full py-4 rounded-xl bg-white text-black font-semibold hover:bg-gray-200 transition">
            Contact Seller
          </button>

          <button className="w-full py-4 rounded-xl border border-white/30 hover:bg-white/10 transition">
            ❤️ Save Horse
          </button>

          <button className="w-full py-4 rounded-xl border border-white/30 hover:bg-white/10 transition">
            Share Listing
          </button>

        </div>

      </div>

    </div>
  );
}

type CardProps = {
  title: string;
  value: string;
};

function InfoCard({ title, value }: CardProps) {
  return (
    <div className="bg-[#111827] rounded-2xl p-5 border border-white/5">

      <p className="text-gray-400 text-sm">
        {title}
      </p>

      <h3 className="font-semibold text-lg mt-2">
        {value}
      </h3>

    </div>
  );
}