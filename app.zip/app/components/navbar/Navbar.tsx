export default function Navbar() {
  return (
    <header className="fixed top-0 left-0 w-full z-50 bg-black/30 backdrop-blur-lg border-b border-white/10">
      <div className="max-w-7xl mx-auto px-8 h-20 flex items-center justify-between">

        <h1 className="text-2xl font-black text-white">
          EquiMaster Pro
        </h1>

        <nav className="flex gap-8 text-gray-300">
          <a href="#">Browse</a>
          <a href="#">Stallions</a>
          <a href="#">Breeders</a>
          <a href="#">About</a>
        </nav>

        <button className="bg-blue-600 px-6 py-3 rounded-xl text-white">
          Login
        </button>

      </div>
    </header>
  );
}