import Link from "next/link";
import Image from "next/image";
import { Horse } from "@/app/data/horses";

type Props = {
  horse: Horse;
};

export default function HorseCard({ horse }: Props) {
  return (
    <Link href={`/horse/${horse.id}`}>

      <div className="group overflow-hidden rounded-3xl bg-[#111827] border border-white/5 hover:border-blue-500 transition-all duration-300">

        <div className="relative">

          <Image
            src={horse.images[0]}
            alt={horse.name}
            width={500}
            height={350}
            className="w-full h-72 object-cover group-hover:scale-105 transition duration-500"
          />

          {horse.verified && (
            <div className="absolute top-4 left-4 bg-blue-600 text-white text-sm px-3 py-1 rounded-full font-semibold">
              ✔ Verified
            </div>
          )}

          <div className="absolute top-4 right-4 bg-black/60 backdrop-blur px-3 py-1 rounded-full text-white text-sm">
            {horse.price}
          </div>

        </div>

        <div className="p-6 space-y-4">

          <div>

            <h3 className="text-2xl font-bold text-white">
              {horse.name}
            </h3>

            <p className="text-blue-400 mt-1">
              {horse.breed}
            </p>

          </div>

          <div className="grid grid-cols-2 gap-3 text-sm">

            <InfoItem
              label="Age"
              value={`${horse.age} yrs`}
            />

            <InfoItem
              label="Height"
              value={`${horse.height} cm`}
            />

            <InfoItem
              label="Gender"
              value={horse.gender}
            />

            <InfoItem
              label="Level"
              value={horse.level}
            />

          </div>

          <div className="flex items-center justify-between pt-4 border-t border-white/10">

            <span className="text-gray-400">
              {horse.country}
            </span>

            <span className="text-blue-400 font-semibold">
              View Details →
            </span>

          </div>

        </div>

      </div>

    </Link>
  );
}

type ItemProps = {
  label: string;
  value: string;
};

function InfoItem({ label, value }: ItemProps) {
  return (
    <div className="bg-[#1f2937] rounded-xl p-3">

      <p className="text-gray-400 text-xs">
        {label}
      </p>

      <p className="font-semibold mt-1 text-white">
        {value}
      </p>

    </div>
  );
}