import HorseCard from "./HorseCard";
import { horses } from "./horses";
import FadeUp from "../animations/FadeUp";

export default function FeaturedHorses() {
  return (
    <section className="bg-[#08111F] py-32">

      <div className="max-w-7xl mx-auto px-6">

        <FadeUp>

          <div className="text-center mb-16">

            <p className="uppercase tracking-[6px] text-blue-500 text-sm font-semibold">
              Premium Collection
            </p>

            <h2 className="mt-4 text-6xl font-black text-white">
              Featured Horses
            </h2>

            <p className="mt-6 max-w-2xl mx-auto text-lg text-gray-400">
              Discover Europe's finest show jumping horses selected from trusted
              breeders and professional riders.
            </p>

          </div>

        </FadeUp>

        <div className="grid gap-10 md:grid-cols-2 xl:grid-cols-3">

          {horses.map((horse) => (
            <FadeUp key={horse.id}>
              <HorseCard horse={horse} />
            </FadeUp>
          ))}

        </div>

      </div>

    </section>
  );
}