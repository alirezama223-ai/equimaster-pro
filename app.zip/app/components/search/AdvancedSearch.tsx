export default function AdvancedSearch() {
  return (
    <section className="bg-[#0A1224] py-24">

      <div className="max-w-7xl mx-auto px-6">

        <div className="rounded-3xl border border-white/10 bg-[#111827] p-8 shadow-2xl">

          <h2 className="text-4xl font-bold text-white mb-8">
            Find Your Perfect Horse
          </h2>

          <div className="grid md:grid-cols-3 lg:grid-cols-6 gap-5">

            <select className="bg-[#1F2937] rounded-xl p-4 text-white">
              <option>Breed</option>
              <option>Hanoverian</option>
              <option>Holsteiner</option>
              <option>Oldenburg</option>
            </select>

            <select className="bg-[#1F2937] rounded-xl p-4 text-white">
              <option>Age</option>
            </select>

            <select className="bg-[#1F2937] rounded-xl p-4 text-white">
              <option>Height</option>
            </select>

            <select className="bg-[#1F2937] rounded-xl p-4 text-white">
              <option>Country</option>
            </select>

            <select className="bg-[#1F2937] rounded-xl p-4 text-white">
              <option>Price</option>
            </select>

            <button className="rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold">
              Search
            </button>

          </div>

        </div>

      </div>

    </section>
  );
}