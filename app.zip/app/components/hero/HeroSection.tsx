import Image from "next/image";

export default function HeroSection() {
  return (
    <section className="relative min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-black text-white overflow-hidden">

      {/* Background Glow */}
      <div className="absolute -left-40 top-40 h-96 w-96 rounded-full bg-blue-600/20 blur-[140px]" />
      <div className="absolute right-0 bottom-0 h-[500px] w-[500px] rounded-full bg-indigo-700/10 blur-[180px]" />

      <div className="relative max-w-7xl mx-auto min-h-screen px-8 pt-32 pb-20 flex items-center">

        <div className="grid lg:grid-cols-2 gap-24 items-center w-full">

          {/* LEFT */}
          <div>

            <p className="uppercase tracking-[6px] text-blue-400 font-semibold mb-6">
              Welcome to EquiMaster Pro
            </p>

            <h1 className="text-6xl lg:text-8xl font-black leading-[0.95]">
              Sport
              <br />
              Horses
              <br />
              Marketplace
            </h1>

            <p className="mt-8 text-xl text-gray-300 leading-9 max-w-xl">
              Buy, sell and discover elite show jumping horses from trusted
              breeders across Europe.
            </p>

            <div className="mt-12 flex flex-wrap gap-5">

              <button className="px-8 py-4 rounded-xl bg-blue-600 hover:bg-blue-700 transition font-semibold text-lg shadow-xl">
                Browse Horses
              </button>

              <button className="px-8 py-4 rounded-xl border border-white/20 hover:bg-white hover:text-black transition text-lg">
                Sell Horse
              </button>

            </div>

            <div className="mt-16 flex gap-12">

              <div>
                <h3 className="text-4xl font-bold">15K+</h3>
                <p className="text-gray-400">Sport Horses</p>
              </div>

              <div>
                <h3 className="text-4xl font-bold">1200+</h3>
                <p className="text-gray-400">Breeders</p>
              </div>

              <div>
                <h3 className="text-4xl font-bold">28</h3>
                <p className="text-gray-400">Countries</p>
              </div>

            </div>

          </div>

          {/* RIGHT */}

          <div className="flex justify-center">

            <div className="relative">

              <div className="absolute inset-0 rounded-[35px] bg-blue-600/20 blur-3xl scale-110"></div>

              <Image
                src="/emi.jpg"
                alt="Sport Horse"
                width={700}
                height={900}
                priority
                className="relative rounded-[35px] shadow-2xl object-cover"
              />

            </div>

          </div>

        </div>

      </div>

    </section>
  );
}