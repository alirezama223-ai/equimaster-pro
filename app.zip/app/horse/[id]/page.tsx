import { notFound } from "next/navigation";
import { horses } from "@/app/data/horses";

import HorseGallery from "@/app/components/horse/HorseGallery";
import HorseInfo from "@/app/components/horse/HorseInfo";
import HorsePedigree from "@/app/components/horse/HorsePedigree";
import HorseDescription from "@/app/components/horse/HorseDescription";
import ContactSeller from "@/app/components/horse/ContactSeller";
import RelatedHorses from "@/app/components/horse/RelatedHorses";

type Props = {
  params: Promise<{
    id: string;
  }>;
};

export default async function HorsePage({ params }: Props) {
  const { id } = await params;

  const horse = horses.find((h) => h.id === Number(id));

  if (!horse) {
    notFound();
  }

  return (
    <main className="bg-[#081223] min-h-screen text-white">

      <div className="max-w-7xl mx-auto px-6 py-20">

        <div className="grid lg:grid-cols-2 gap-16">

          <HorseGallery horse={horse} />

          <HorseInfo horse={horse} />

        </div>

        <div className="mt-20">
          <HorsePedigree horse={horse} />
        </div>

        <div className="mt-20">
          <HorseDescription horse={horse} />
        </div>

        <div className="mt-20">
          <ContactSeller horse={horse} />
        </div>

        <div className="mt-20">
          <RelatedHorses currentHorse={horse} />
        </div>

      </div>

    </main>
  );
}