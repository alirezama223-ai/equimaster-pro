import Image from "next/image";

export default function HorseGallery() {
  return (
    <div>

      <Image
        src="/emi.jpg"
        alt="Horse"
        width={700}
        height={700}
        className="rounded-3xl"
      />

      <div className="grid grid-cols-4 gap-4 mt-4">

        <Image src="/emi.jpg" alt="" width={150} height={150} className="rounded-xl cursor-pointer"/>

        <Image src="/emi.jpg" alt="" width={150} height={150} className="rounded-xl cursor-pointer"/>

        <Image src="/emi.jpg" alt="" width={150} height={150} className="rounded-xl cursor-pointer"/>

        <Image src="/emi.jpg" alt="" width={150} height={150} className="rounded-xl cursor-pointer"/>

      </div>

    </div>
  );
}