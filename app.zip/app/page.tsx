import Navbar from "./components/navbar/Navbar";
import HeroSection from "./components/hero/HeroSection";
import FeaturedHorses from "./components/featured/FeaturedHorses";
import AdvancedSearch from "./components/search/AdvancedSearch";
import PremiumStallions from "./components/stallions/PremiumStallions";
import FadeUp from "./components/animations/FadeUp";

export default function Home() {
  return (
    <>
      <Navbar />

      <FadeUp>
        <HeroSection />
      </FadeUp>

      <FadeUp>
        <FeaturedHorses />
      </FadeUp>

      <FadeUp>
        <AdvancedSearch />
      </FadeUp>

      <FadeUp>
        <PremiumStallions />
      </FadeUp>
    </>
  );
}