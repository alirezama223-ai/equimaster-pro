export type Horse = {
  id: number;
  name: string;
  breed: string;
  age: number;
  height: number;
  country: string;
  price: string;
  image: string;
  verified: boolean;
};

export const horses: Horse[] = [
  {
    id: 1,
    name: "Emerald Star Z",
    breed: "Hanoverian",
    age: 6,
    height: 167,
    country: "Germany",
    price: "€32,000",
    image: "/emi.jpg",
    verified: true,
  },

  {
    id: 2,
    name: "Casco Blue",
    breed: "Oldenburg",
    age: 5,
    height: 170,
    country: "Belgium",
    price: "€45,000",
    image: "/emi.jpg",
    verified: true,
  },

  {
    id: 3,
    name: "Tobago Star",
    breed: "Zangersheide",
    age: 7,
    height: 171,
    country: "Netherlands",
    price: "€58,000",
    image: "/emi.jpg",
    verified: true,
  },

  {
    id: 4,
    name: "United Dream",
    breed: "KWPN",
    age: 5,
    height: 168,
    country: "France",
    price: "€39,000",
    image: "/emi.jpg",
    verified: false,
  },

  {
    id: 5,
    name: "Casall Queen",
    breed: "Holsteiner",
    age: 8,
    height: 169,
    country: "Germany",
    price: "€74,000",
    image: "/emi.jpg",
    verified: true,
  },

  {
    id: 6,
    name: "Chacfly Lady",
    breed: "Oldenburg",
    age: 6,
    height: 168,
    country: "Netherlands",
    price: "€54,000",
    image: "/emi.jpg",
    verified: true,
  },
];