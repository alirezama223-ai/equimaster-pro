"use client";

import Image from "next/image";
import type { Horse } from "./horses";

type HorseCardProps = {
  horse: Horse;
};

export default function HorseCard({ horse }: HorseCardProps) {
  return (
    <div
      className="
      group
      overflow-hidden
      rounded-3xl
      bg-[#111827]
      border
      border-white/10
      transition-all
      duration-500
      hover:-translate-y-2
      hover:border-blue-500
      hover:shadow-[0_0_40px_rgba(37,99,235,.35)]
      "
    >
      {/* IMAGE */}

      <div className="relative h-80 overflow-hidden">

        <Image
          src={horse.image}
          alt={horse.name}
          fill
          className="
          object-cover
          transition-transform
          duration-700
          group-hover:scale-110
          "
        />

        {horse.verified && (
          <span className="absolute top-4 left-4 rounded-full bg-blue-600 px-3 py-1 text-xs font-bold text-white">
            ✓ Verified
          </span>
        )}

        <button className="absolute top-4 right-4 h-10 w-10 rounded-full bg-black/40 backdrop-blur-md text-white hover:bg-red-500 transition">
          ♥
        </button>
      </div>

      {/* CONTENT */}

      <div className="p-6">

        <h3 className="text-2xl font-bold text-white">
          {horse.name}
        </h3>

        <p className="mt-2 text-gray-400">
          {horse.breed}
        </p>

        <div className="mt-6 grid grid-cols-3 gap-3">

          <div className="rounded-xl bg-[#182540] p-3 text-center">

            <p className="text-xs text-gray-400">
              Age
            </p>

            <p className="font-bold text-white">
              {horse.age}
            </p>

          </div>

          <div className="rounded-xl bg-[#182540] p-3 text-center">

            <p className="text-xs text-gray-400">
              Height
            </p>

            <p className="font-bold text-white">
              {horse.height} cm
            </p>

          </div>

          <div className="rounded-xl bg-[#182540] p-3 text-center">

            <p className="text-xs text-gray-400">
              Country
            </p>

            <p className="font-bold text-white">
              {horse.country}
            </p>

          </div>

        </div>

        <div className="mt-6 flex items-center justify-between">

          <div>

            <p className="text-xs text-gray-400">
              Price
            </p>

            <p className="text-3xl font-black text-blue-400">
              {horse.price}
            </p>

          </div>

          <button className="rounded-xl bg-blue-600 px-5 py-3 font-semibold text-white hover:bg-blue-500 transition">
            View
          </button>

        </div>

      </div>
    </div>
  );
}