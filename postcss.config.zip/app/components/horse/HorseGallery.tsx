"use client";

import Image from "next/image";
import { useState } from "react";
import { Horse } from "@/app/data/horses";

type Props = {
  horse: Horse;
};

export default function HorseGallery({ horse }: Props) {
  const images = [
    horse.image,
    horse.image,
    horse.image,
    horse.image,
  ];

  const [selectedImage, setSelectedImage] = useState(images[0]);
  const [open, setOpen] = useState(false);

  return (
    <>
      <div>

        {/* Main Image */}

        <div className="relative overflow-hidden rounded-3xl">

          <div
            onClick={() => setOpen(true)}
            className="cursor-zoom-in"
          >
            <Image
              src={selectedImage}
              alt={horse.name}
              width={700}
              height={700}
              className="rounded-3xl object-cover w-full transition duration-300 hover:scale-105"
            />
          </div>

          {horse.verified && (
            <div className="absolute top-4 left-4 bg-blue-600 text-white px-4 py-2 rounded-full text-sm font-semibold">
              ✔ Verified
            </div>
          )}

        </div>

        {/* Thumbnails */}

        <div className="grid grid-cols-4 gap-4 mt-4">

          {images.map((img, index) => (

            <button
              key={index}
              onClick={() => setSelectedImage(img)}
              className={`overflow-hidden rounded-xl border-2 transition ${
                selectedImage === img
                  ? "border-blue-500"
                  : "border-transparent"
              }`}
            >

              <Image
                src={img}
                alt=""
                width={150}
                height={150}
                className="rounded-xl object-cover hover:scale-110 transition duration-300"
              />

            </button>

          ))}

        </div>

      </div>

      {/* Lightbox */}

      {open && (

        <div
          className="fixed inset-0 bg-black/90 z-50 flex items-center justify-center"
          onClick={() => setOpen(false)}
        >

          <button
            className="absolute top-6 right-8 text-white text-6xl"
          >
            ×
          </button>

          <Image
            src={selectedImage}
            alt={horse.name}
            width={1200}
            height={1200}
            className="max-w-[90vw] max-h-[90vh] object-contain rounded-3xl"
          />

        </div>

      )}

    </>
  );
}